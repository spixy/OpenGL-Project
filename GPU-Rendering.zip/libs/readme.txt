
--------------
-- FreeGLUT --
--------------

web: http://freeglut.sourceforge.net
download (MSVC Package): http://www.transmissionzero.co.uk/software/freeglut-devel/

Nebo st�hn�te a zkompilujte zdrojov� k�d.

----------
-- GLEW --
----------

web: http://glew.sourceforge.net/
download: https://sourceforge.net/projects/glew/files/glew/2.0.0/glew-2.0.0-win32.zip/download

Nebo st�hn�te a zkompilujte zdrojov� k�d.

-----------
-- DevIL --
-----------

web: http://openil.sourceforge.net/
download: http://downloads.sourceforge.net/openil/DevIL-SDK-x86-1.7.8.zip

Nebo st�hn�te a zkompilujte zdrojov� k�d.

---------
-- GLM --
---------

web: http://glm.g-truc.net/
download: https://github.com/g-truc/glm/releases/download/0.9.7.6/glm-0.9.7.6.zip

-----------------
-- AntTweakBar --
-----------------

web: http://anttweakbar.sourceforge.net/doc/tools:anttweakbar
download: http://anttweakbar.sourceforge.net/doc/tools:anttweakbar:download

Nebo st�hn�te a zkompilujte zdrojov� k�d.
