Nefunguje to, ale odovzdal som to kezde som tomu venoval dost casu.
Vystup z konzole u mna doma (mam najnovsi AMD driver):

Vendor   : ATI Technologies Inc.
Renderer : AMD Radeon (TM) R9 380 Series
Version  : 4.3.13497 Core Profile/Debug Context 23.20.788.0

Shaders are reloaded
Couldn't load texture: ../../textures/wood.jpg, error: 1291
Couldn't load texture: ../../textures/Lenna.jpg, error: 1291
Press any key to continue . . .

1291 == IL_INVALID_EXTENSION, na PC v skole by to nemalo robit, co som skusal